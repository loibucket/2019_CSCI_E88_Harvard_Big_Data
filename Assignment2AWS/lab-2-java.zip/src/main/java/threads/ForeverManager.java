package threads;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ForeverManager {

	private ExecutorService workersThreadPoolService = null;

	public ForeverManager() {
	}
	
	public void runWorkers(int numberOfThreads){
		workersThreadPoolService = Executors.newFixedThreadPool(numberOfThreads);
		List<ForeverWorker> workers = new LinkedList<>();
		for (int i=0; i<numberOfThreads; i++) {
			String threadName = "workerThread" + i;
			workers.add(new ForeverWorker(threadName));
		}
	   	System.out.println("runWorkers(): created all workers");
		try {
			workersThreadPoolService.invokeAll(workers);
		} catch (InterruptedException e) {
		   	System.out.println("Got InterruptedException while shutting down workers, aborting");
		}
	   	System.out.println("runGenerators(): finished waiting for completion");
	}

	public static void main(String[] args) {
		if (args.length < 1) {
			System.out.println("Usage: java ForeverManager <numberOfThreads>");
			System.exit(-1);
		} 
		// TODO: should really handle exceptions here 
		int numberOfThreads = Integer.parseInt(args[0]);
		ForeverManager manager = new ForeverManager();		
		manager.runWorkers(numberOfThreads);
		System.out.println("Main method is finished");
	}

}
