package threads;

public class UtilConstants {

	// constants for generated numbers for lines
	public static String ITEMS_SEPARATOR = " ";
	public static int ITEMS_RANGE_START = 0;
	public static int ITEMS_RANGE_END = 10;
	public static int ITEMS_NUMBER_PER_LINE = 3;

	public static String FILE_NAME_SEPARATOR = "_";
	public static String FILE_NAME_ENDING = ".txt";
	public static String BASE_FILE_NAME = "data";

}
