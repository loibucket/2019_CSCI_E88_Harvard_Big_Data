package threads;

import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.concurrent.ThreadLocalRandom;

public class SimpleDataGenerator {
	
	public SimpleDataGenerator() {
	}
	
	public void generateDataFile(String fileName, int numberOfLines) {
		try (BufferedWriter writer = Files.newBufferedWriter( Paths.get(fileName) )) {
			for (int i=0; i<numberOfLines; i++) {
				StringBuilder line = new StringBuilder();
				for (int j=0; j<UtilConstants.ITEMS_NUMBER_PER_LINE; j++) {
					int randomNum = ThreadLocalRandom.current().nextInt(UtilConstants.ITEMS_RANGE_START, UtilConstants.ITEMS_RANGE_END + 1);
					line.append(randomNum);
					if (j < UtilConstants.ITEMS_NUMBER_PER_LINE-1) {
						line.append(UtilConstants.ITEMS_SEPARATOR);
					}
				}
			    writer.write(line.toString());
			    if (i < numberOfLines-1 ) {
					writer.newLine();
				}
			}
			System.out.println("generated data file OK: " + fileName);
		} catch (Exception e) {
			System.out.println("ERROR: no data file was generated: " + e.getMessage());
		}

	}
		
	public static void main(String[] args) {
		if (args.length < 2) {
			System.out.println("Usage: java SimpleDataGenerator <outputFileName> <numberOfLines>");
			System.exit(-1);
		}		
		String fileName = args[0];
		// TODO: should really handle exceptions here 
		int numberOfLines = Integer.parseInt(args[1]);
		SimpleDataGenerator dataGenerator = new SimpleDataGenerator();
		dataGenerator.generateDataFile(fileName, numberOfLines);
	}

}
