package threads;

import java.util.concurrent.Callable;
import java.util.concurrent.ThreadLocalRandom;

public class ForeverWorker implements Callable<String> {

	private String threadName;
	
	public ForeverWorker(String generatorId) {
		this.threadName = generatorId;
	}

	@Override
	public String call() {
		System.out.println("thread [" + threadName + "] - starting work....");
		while (true) {
			try {
				StringBuilder line = new StringBuilder();
				for (int j=0; j<UtilConstants.ITEMS_NUMBER_PER_LINE; j++) {
					int randomNum = ThreadLocalRandom.current().nextInt(UtilConstants.ITEMS_RANGE_START, UtilConstants.ITEMS_RANGE_END + 1);
					line.append(randomNum);
					if (j < UtilConstants.ITEMS_NUMBER_PER_LINE-1) {
						line.append(UtilConstants.ITEMS_SEPARATOR);
					}
				}
				// sleep for 1 sec
			Thread.sleep(1000l);
			System.out.println("thread [" + threadName + "] generated line: " + line);
			} catch (Exception e) {
				System.out.println("thread [" + threadName + "]: ERROR:: " + e.getMessage());
				return "done";
			}
		}
	}

}
