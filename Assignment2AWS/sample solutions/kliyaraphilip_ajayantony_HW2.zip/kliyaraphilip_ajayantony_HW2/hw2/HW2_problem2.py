# reference : lab2 code : lab2_multi_processing_forever.py
# Problem 2: Analyze a I/O intensive multi-threaded process
import argparse
from random import randint
from time import sleep
import multiprocessing
import os

NEW_LINE_CHAR = '\n'

# argument parser
prog = "hw2_problem2"
desc = "Generate a file with with 10k random numbers per thread and repeat"
parser = argparse.ArgumentParser(prog=prog, description=desc)
parser.add_argument('--numThreads', '-nt', default=2, type=int)       # argument to hold number of threads

parsed_args = parser.parse_args()                                     # parse arguments
numThreads = parsed_args.numThreads


"""
purpose: Function to write random numbers to file and repeat.
"""

def writeRandomNumbersToFile():
    sleep(1)
    file_name = 'random_number_file_' + str(os.getpid())    # file name
    file_to_process = open(file_name, "w")                  # open file to write
    print('writing to file {0}'.format(file_name))
    for line_number in range(10000):
        file_to_process.write(str(randint(0,1000000)) + NEW_LINE_CHAR)
    file_to_process.close()
    print('deleting file {0}'.format(file_name))
    os.remove(file_name)
    writeRandomNumbersToFile()                              # write another 10k numbers


jobs = []
for thrds in range(numThreads):
    t = multiprocessing.Process(target=writeRandomNumbersToFile)
    jobs.append(t)
    t.start()  # new child process is started at this point, it has its own execution flow

for curr_job in jobs:
    curr_job.join()                                         # wait for all process to finish

print("Process Completed")
