# reference : lab2 code : lab2_multi_processing_forever.py
# Problem 1: Analyze a CPU intensive multi-threaded process
import argparse
from random import randint
from time import sleep
import multiprocessing
import os

# argument parser
prog = "hw2_problem1"
desc = "Generate fibnoacci series numbers"
parser = argparse.ArgumentParser(prog=prog, description=desc)
parser.add_argument('--numThreads', '-nt', default=2, type=int)   # argument to hold number of threads

parsed_args = parser.parse_args()                                 # parse arguments
numThreads = parsed_args.numThreads



"""
args   : num1 : previous but one fibonacci series number generated
         num2 : previous fibonacci series number generated
purpose: Function to generate fibonacci series number continuously.
"""


def generateNextFibonacci(num1,num2):
    sleep(1)                                 # sleep for 1 second
    next_fibo = num1 + num2                  # next number in series
    print('Python thread process id : {0}'.format(os.getpid())) # print pid
    print('fibo : {0}'.format(next_fibo))
    num1 = num2
    num2 = next_fibo
    generateNextFibonacci(num1,num2)         # recursively call for endless loop

jobs = []
for thrds in range(numThreads):
    num1 = 1                                  # first number in fibonacci series
    num2 = 1                                  # second number in fibonacci series
    t = multiprocessing.Process(target=generateNextFibonacci, args=(num1,num2))
    jobs.append(t)
    t.start()  # new child process is started at this point, it has its own execution flow

for curr_job in jobs:                         # wait for all process to finish
    curr_job.join()

print("Process Completed")
