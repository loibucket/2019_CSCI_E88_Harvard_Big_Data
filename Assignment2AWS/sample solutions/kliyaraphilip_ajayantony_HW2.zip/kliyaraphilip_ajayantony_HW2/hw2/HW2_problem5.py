# reference : lab2 code : lab2_shared_count.py
# Problem 5: Bonus: top N queries : get top 5 URLs by avg daily TTFB
# Finding average TFFB by url for every day, then find top 5 (lowest tffb) url's for each day

import multiprocessing
from multiprocessing import Process, Value, Lock
import glob


"""
args   : manager : multiprocessing manager
         data_dict : multiprocessing dict to hold data
         date_str : date of event
         url_text : url string
purpose: Function adds date for every url
"""


def add_url(manager,data_dict,date_str,url_text):
    if url_text in data_dict[date_str]:
        return                                                     # return date already exists
    else:                                                          # add date key
        temp_dict = data_dict[date_str]
        temp_dict[url_text] = manager.dict()
        data_dict[date_str] = temp_dict

"""
args   : manager : multiprocessing manager
         data_dict : multiprocessing dict to hold data
         date_str : date key
         url_text : url string
         tffb : time to first byte for the event
purpose: Function counts events for an url for a day and adds up the tffb
"""


def add_tffb(manager,data_dict,url_text,date_str,tffb):
    if 'count' in data_dict[url_text][date_str]:                # if user id exits, increment counter for event
        temp_dict1 = data_dict[url_text]
        temp_dict2 = temp_dict1[date_str]
        temp_dict2['count'] += 1
        temp_dict2['tffb'] += tffb
        temp_dict1[date_str] = temp_dict2
        data_dict[url_text] = temp_dict1
    else:
        temp_dict1 = data_dict[url_text]                       # add new user id and instantiate counter to 1
        temp_dict2 = temp_dict1[date_str]
        temp_dict2['count'] = 1
        temp_dict2['tffb'] = tffb
        temp_dict1[date_str] = temp_dict2
        data_dict[url_text] = temp_dict1


"""
args   : manager : multiprocessing manager
         file : path of file to process
         lock : lock to support atomic updates to dict
         data_dict : multiprocessing dict to hold data
purpose: Function creates a process for every file and processes it to extract required attributes.
"""


def process_file(manager, file, lock, data_dict):
    f = open(file, 'r')                                                               # open file

    for file_line in f:                                                               # for every line in file
        line_list = file_line.split(',')                                              # create list of strings
        datetime, url = line_list[1:3]                                                # capture attributes
        date = datetime[:10]                                                          # get date only
        tffb = float(line_list[-1])                                                         # get event tffb

        with lock:                                                                    # lock to ensure atomic updates
            if date in data_dict:
                add_url(manager,data_dict,date,url)                                  # add url to dict
                add_tffb(manager,data_dict,date,url,tffb)                             # add tffb
            else:
                data_dict[date] = manager.dict()                                       # add date key
                add_url(manager,data_dict,date,url)                                  # add url to dict
                add_tffb(manager,data_dict,date,url,tffb)                             # add tffb

    f.close()                                                                         # close file


if __name__ == '__main__':
    final_dict = dict()                                                               # final regular dict
    with multiprocessing.Manager() as manager:                                        # initiate multiprocessing manager
        data_dict = manager.dict()                                                    # shared state dict
        lock = Lock()                                                                 # instantiate lock
        jobs = []                                                                     # place holder list for jobs

        path = '/home/centos/input_files/*'                                           # path of file(s) location
        files = glob.glob(path)                                                       # find all path names matching pattern

        for file in files:                                                            # process every file
            print('processing file = ' + str(file))                                   # start a process for every file
            t = multiprocessing.Process(
                target=process_file,
                args=(manager, file, lock, data_dict))
            jobs.append(t)                                                            # add process to jobs list
            t.start()                                                                 # start the child process

        for curr_job in jobs:                                                         # wait for all process to finish
            curr_job.join()

        print("Process Completed")
        final_dict = data_dict.copy()                                                 # copy shared dict

    for dt in final_dict.keys():
        for url in final_dict[dt].keys():                                             # avg tffb for each url per day
            final_dict[dt][url] = final_dict[dt][url]['tffb']/final_dict[dt][url]['count']

    for dt in sorted(final_dict.keys()):                                              # for every date get top 5 tffb
        t_dict = final_dict[dt]                                                       # dict for a date

        counter = 0;                                                                  # sort by tffb in asc order
        for url in sorted(t_dict, key=t_dict.get):
            counter += 1
            print(dt, url, t_dict[url])
            if counter == 5:                                                          # pick top 5 only
                break
