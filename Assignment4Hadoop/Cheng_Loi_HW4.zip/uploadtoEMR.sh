#master
scp -i BigDataHarvard.pem *.py hadoop@ec2-52-14-219-9.us-east-2.compute.amazonaws.com:.

#core
scp -i BigDataHarvard.pem *.py hadoop@ec2-3-15-150-151.us-east-2.compute.amazonaws.com:.

#core
scp -i BigDataHarvard.pem *.py hadoop@ec2-18-223-213-230.us-east-2.compute.amazonaws.com:.